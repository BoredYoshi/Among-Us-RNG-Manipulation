﻿using MelonLoader;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle(AmongUsRNG.BuildInfo.Name)]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(AmongUsRNG.BuildInfo.Company)]
[assembly: AssemblyProduct(AmongUsRNG.BuildInfo.Name)]
[assembly: AssemblyCopyright("Created by " + AmongUsRNG.BuildInfo.Author)]
[assembly: AssemblyTrademark(AmongUsRNG.BuildInfo.Company)]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
//[assembly: Guid("")]
[assembly: AssemblyVersion(AmongUsRNG.BuildInfo.Version)]
[assembly: AssemblyFileVersion(AmongUsRNG.BuildInfo.Version)]
[assembly: NeutralResourcesLanguage("en")]
[assembly: MelonInfo(typeof(AmongUsRNG.AmongUsRNG), AmongUsRNG.BuildInfo.Name, AmongUsRNG.BuildInfo.Version, AmongUsRNG.BuildInfo.Author, AmongUsRNG.BuildInfo.DownloadLink)]
[assembly: MelonGame(null, null)]